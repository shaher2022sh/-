import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import {
  findAllThemes,
  findThemeById,
  findThemesByCategory,
  createOrder,
  seedThemes,
} from "./queries/themes";

export const themeRouter = createRouter({
  // Seed default themes
  seed: publicQuery.mutation(async () => {
    await seedThemes();
    return { success: true };
  }),

  // List all active themes
  list: publicQuery.query(async () => {
    return findAllThemes();
  }),

  // Get single theme by ID
  byId: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const results = await findThemeById(input.id);
      return results[0] || null;
    }),

  // List themes by category
  byCategory: publicQuery
    .input(z.object({ category: z.string() }))
    .query(async ({ input }) => {
      return findThemesByCategory(input.category);
    }),

  // Create a new order
  createOrder: publicQuery
    .input(
      z.object({
        themeId: z.number(),
        customerName: z.string().optional(),
        customerEmail: z.string().email().optional(),
        customerPhone: z.string().optional(),
        amount: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      const orderId = await createOrder({
        themeId: input.themeId,
        customerName: input.customerName,
        customerEmail: input.customerEmail,
        customerPhone: input.customerPhone,
        amount: input.amount,
        status: "pending",
      });
      return { orderId, status: "pending" };
    }),
});
