import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { updateOrderStatus, findOrderBySallaId } from "./queries/themes";

// Salla webhook handler
// When a customer pays on Salla, this endpoint receives the notification
export const sallaRouter = createRouter({
  // Webhook endpoint for Salla order events
  webhook: publicQuery
    .input(
      z.object({
        event: z.string(), // order.created, order.paid, etc.
        data: z.record(z.unknown()),
      })
    )
    .mutation(async ({ input }) => {
      const { event, data } = input;

      // Log the webhook for debugging
      console.log("Salla webhook received:", event, data);

      // Handle payment confirmation
      if (event === "order.paid" || event === "order.completed") {
        const orderData = data as {
          id?: string;
          customer?: { email?: string; phone?: string };
          items?: Array<{ product?: { id?: string; name?: string } }>;
        };

        const sallaOrderId = orderData.id;

        if (sallaOrderId) {
          // Check if we have a matching order
          const existingOrders = await findOrderBySallaId(sallaOrderId);

          if (existingOrders.length > 0) {
            // Update existing order
            await updateOrderStatus(existingOrders[0].id, "paid", sallaOrderId);
          }

          return {
            success: true,
            message: "Payment processed",
            orderId: sallaOrderId,
          };
        }
      }

      return { success: true, message: "Webhook received" };
    }),

  // Manual status check (for frontend polling)
  checkPayment: publicQuery
    .input(z.object({ sallaOrderId: z.string() }))
    .query(async ({ input }) => {
      const orders = await findOrderBySallaId(input.sallaOrderId);
      if (orders.length === 0) {
        return { found: false, status: null };
      }
      return { found: true, status: orders[0].status };
    }),
});
