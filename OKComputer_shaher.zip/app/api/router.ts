import { createRouter, publicQuery } from "./middleware";
import { themeRouter } from "./themeRouter";
import { sallaRouter } from "./sallaRouter";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),

  theme: themeRouter,
  salla: sallaRouter,
});

export type AppRouter = typeof appRouter;
