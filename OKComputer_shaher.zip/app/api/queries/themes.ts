import { getDb } from "./connection";
import { themes, orders } from "@db/schema";
import { eq, desc } from "drizzle-orm";

// Get all active themes
export async function findAllThemes() {
  return getDb()
    .select()
    .from(themes)
    .where(eq(themes.isActive, true))
    .orderBy(desc(themes.createdAt));
}

// Get theme by ID
export async function findThemeById(id: number) {
  return getDb()
    .select()
    .from(themes)
    .where(eq(themes.id, id))
    .limit(1);
}

// Get themes by category
export async function findThemesByCategory(category: string) {
  return getDb()
    .select()
    .from(themes)
    .where(eq(themes.category, category));
}

// Create an order
export async function createOrder(data: {
  themeId: number;
  customerName?: string;
  customerEmail?: string;
  customerPhone?: string;
  sallaOrderId?: string;
  amount: number;
  status?: string;
}) {
  const result = await getDb()
    .insert(orders)
    .values({
      themeId: data.themeId,
      customerName: data.customerName,
      customerEmail: data.customerEmail,
      customerPhone: data.customerPhone,
      sallaOrderId: data.sallaOrderId,
      amount: data.amount,
      status: data.status || "pending",
    })
    .$returningId();
  return result[0].id;
}

// Update order status
export async function updateOrderStatus(
  orderId: number,
  status: string,
  sallaOrderId?: string
) {
  const updateData: Record<string, unknown> = { status };
  if (sallaOrderId) updateData.sallaOrderId = sallaOrderId;
  if (status === "installed") updateData.installedAt = new Date();

  await getDb()
    .update(orders)
    .set(updateData)
    .where(eq(orders.id, orderId));
}

// Find order by Salla order ID
export async function findOrderBySallaId(sallaOrderId: string) {
  return getDb()
    .select()
    .from(orders)
    .where(eq(orders.sallaOrderId, sallaOrderId))
    .limit(1);
}

// Seed default themes
export async function seedThemes() {
  const db = getDb();
  const existing = await db.select().from(themes).limit(1);
  if (existing.length > 0) return; // Already seeded

  await db.insert(themes).values([
    {
      nameAr: "ثيم رابح",
      nameEn: "Rabeh Theme",
      description: "ثيم إلكتروني احترافي مع معاينة حية — مناسب لجميع المتاجر",
      price: 260,
      originalPrice: 1399,
      discountLabel: "خصم 81%",
      image: "/images/promo-banner-1.jpg",
      category: "إلكترونية",
      tags: "#إلكترونيات,#متجر,#تجاوب",
      sallaProductUrl: "https://salla.sa/abdalin",  // ابداع لاين
    },
    {
      nameAr: "ثيم فخامة",
      nameEn: "Luxury Theme",
      description: "تصميم فاخر بألوان ذهبية — مثالي للمجوهرات والأزياء",
      price: 349,
      originalPrice: 999,
      discountLabel: "خصم 65%",
      image: "/images/promo-banner-2.jpg",
      category: "فاخرة",
      tags: "#فاخر,#مجوهرات,#أزياء",
      sallaProductUrl: "https://salla.sa/abdalin",  // ابداع لاين
    },
    {
      nameAr: "ثيم الاحترافية",
      nameEn: "Pro Theme",
      description: "تصميم عصري بتقنية أحدث — سرعة وأداء ممتاز",
      price: 199,
      originalPrice: 799,
      discountLabel: "خصم 75%",
      image: "/images/hero-banner.jpg",
      category: "عصرية",
      tags: "#احترافي,#سريع,#عصري",
      sallaProductUrl: "https://salla.sa/abdalin",  // ابداع لاين
    },
    {
      nameAr: "ثيم المجوهرات",
      nameEn: "Jewelry Theme",
      description: "تصميم فاخر للمجوهرات والذهب — ألوان ذهبية وأنيقة",
      price: 349,
      originalPrice: 1199,
      discountLabel: "خصم 71%",
      image: "/images/product-bracelet-1.jpg",
      category: "متخصصة",
      tags: "#مجوهرات,#ذهب,#فاخر",
      sallaProductUrl: "https://salla.sa/abdalin",  // ابداع لاين
    },
    {
      nameAr: "ثيم العطور",
      nameEn: "Perfume Theme",
      description: "تصميم أنيق للعطور والتجميل — فخامة وبساطة",
      price: 299,
      originalPrice: 899,
      discountLabel: "خصم 67%",
      image: "/images/product-bracelet-2.jpg",
      category: "متخصصة",
      tags: "#عطور,#تجميل,#أنيق",
      sallaProductUrl: "https://salla.sa/abdalin",  // ابداع لاين
    },
    {
      nameAr: "ثيم الأزياء",
      nameEn: "Fashion Theme",
      description: "تصميم عصري للأزياء والملابس — مرن ومتجاوب",
      price: 279,
      originalPrice: 999,
      discountLabel: "خصم 72%",
      image: "/images/product-ring-2.jpg",
      category: "متخصصة",
      tags: "#أزياء,#ملابس,#عصري",
      sallaProductUrl: "https://salla.sa/abdalin",  // ابداع لاين
    },
    {
      nameAr: "ثيم الإلكترونيات",
      nameEn: "Electronics Theme",
      description: "تصميم تقني للإلكترونيات — احترافي وعملي",
      price: 249,
      originalPrice: 899,
      discountLabel: "خصم 72%",
      image: "/images/product-earring-1.jpg",
      category: "إلكترونية",
      tags: "#إلكترونيات,#تقني,#احترافي",
      sallaProductUrl: "https://salla.sa/abdalin",  // ابداع لاين
    },
  ]);
}
