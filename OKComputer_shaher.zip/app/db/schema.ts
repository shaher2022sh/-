import {
  mysqlTable,
  serial,
  varchar,
  text,
  timestamp,
  int,
  boolean,
} from "drizzle-orm/mysql-core";

// Themes table - stores all available themes
export const themes = mysqlTable("themes", {
  id: serial("id").primaryKey(),
  nameAr: varchar("name_ar", { length: 255 }).notNull(),
  nameEn: varchar("name_en", { length: 255 }).notNull(),
  description: text("description"),
  price: int("price").notNull(),
  originalPrice: int("original_price"),
  discountLabel: varchar("discount_label", { length: 50 }),
  image: varchar("image", { length: 500 }),
  category: varchar("category", { length: 100 }).notNull(),
  tags: varchar("tags", { length: 255 }),
  sallaProductId: varchar("salla_product_id", { length: 100 }),
  sallaProductUrl: varchar("salla_product_url", { length: 500 }),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Orders table - tracks purchases
export const orders = mysqlTable("orders", {
  id: serial("id").primaryKey(),
  themeId: int("theme_id").notNull(),
  customerName: varchar("customer_name", { length: 255 }),
  customerEmail: varchar("customer_email", { length: 255 }),
  customerPhone: varchar("customer_phone", { length: 50 }),
  sallaOrderId: varchar("salla_order_id", { length: 100 }),
  sallaStoreUrl: varchar("salla_store_url", { length: 255 }),
  amount: int("amount").notNull(),
  status: varchar("status", { length: 50 }).default("pending").notNull(), // pending, paid, installed, cancelled
  installedAt: timestamp("installed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Theme = typeof themes.$inferSelect;
export type InsertTheme = typeof themes.$inferInsert;
export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;
