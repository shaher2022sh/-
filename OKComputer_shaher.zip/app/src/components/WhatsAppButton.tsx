import { Phone } from "lucide-react";

export default function WhatsAppButton() {
  return (
    <a
      href="https://wa.me/966500000000?text=مرحباً%20ابداع%20لاين%20أبي%20أستفسر%20عن%20ثيم"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-20 right-4 z-50 w-14 h-14 bg-success rounded-full flex items-center justify-center shadow-whatsapp animate-pulse-ring hover:scale-110 transition-transform"
    >
      <Phone className="w-7 h-7 text-white" strokeWidth={2} />
    </a>
  );
}
