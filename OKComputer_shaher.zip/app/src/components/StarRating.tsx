import { Star } from "lucide-react";

interface StarRatingProps {
  rating?: number;
  size?: number;
}

export default function StarRating({ rating = 5, size = 18 }: StarRatingProps) {
  return (
    <div className="flex items-center gap-0.5">
      {[...Array(5)].map((_, i) => (
        <Star
          key={i}
          className={i < rating ? "text-[#6C3CBC] fill-[#6C3CBC]" : "text-gray-300"}
          size={size}
          strokeWidth={1.5}
        />
      ))}
    </div>
  );
}
