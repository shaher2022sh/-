import { Home, User, Sparkles, Heart, ClipboardList } from "lucide-react";

const navItems = [
  { icon: Home, label: "الرئيسية", active: true },
  { icon: User, label: "حسابي", active: false },
  { icon: Sparkles, label: "العروض", active: false },
  { icon: Heart, label: "المفضلة", active: false },
  { icon: ClipboardList, label: "الطلبات", active: false },
];

export default function BottomNav() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 h-16">
      <div className="max-w-[430px] mx-auto flex items-center justify-around h-full">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.label}
              className={`flex flex-col items-center gap-1 px-3 py-1 relative ${
                item.active ? "text-[#6C3CBC]" : "text-gray-400"
              }`}
            >
              <Icon className="w-6 h-6" strokeWidth={item.active ? 2 : 1.5} />
              <span className="text-[11px] font-medium">{item.label}</span>
              {item.active && (
                <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-[#6C3CBC] rounded-full" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
