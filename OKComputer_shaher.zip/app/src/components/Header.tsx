import { User, ShoppingBag, Heart, Globe } from "lucide-react";

export default function Header() {
  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-100 shadow-sm">
      <div className="flex items-center justify-between px-3 h-16">
        {/* Right side - Account & Cart */}
        <div className="flex items-center gap-2">
          <button className="p-2 hover:bg-purple-50 rounded-full transition-colors">
            <User className="w-5 h-5 text-[#1A1040]" strokeWidth={1.5} />
          </button>
          <button className="p-2 hover:bg-purple-50 rounded-full transition-colors relative">
            <ShoppingBag className="w-5 h-5 text-[#1A1040]" strokeWidth={1.5} />
            <span className="absolute -top-0.5 -right-0.5 bg-[#6C3CBC] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
              0
            </span>
          </button>
        </div>

        {/* Center - Logo */}
        <div className="flex flex-col items-center">
          <img
            src="/images/logo-ibdaa-line.jpg"
            alt="ابداع لاين"
            className="h-10 w-auto object-contain"
          />
        </div>

        {/* Left side - Wishlist & Language */}
        <div className="flex items-center gap-2">
          <button className="p-2 hover:bg-purple-50 rounded-full transition-colors">
            <Heart className="w-5 h-5 text-[#1A1040]" strokeWidth={1.5} />
          </button>
          <button className="p-2 hover:bg-purple-50 rounded-full transition-colors">
            <Globe className="w-5 h-5 text-[#1A1040]" strokeWidth={1.5} />
          </button>
        </div>
      </div>
    </header>
  );
}
