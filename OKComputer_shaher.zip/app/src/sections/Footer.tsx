import { useState } from "react";
import { motion } from "framer-motion";
import { Mail, Smartphone, Phone, ShieldCheck, Award } from "lucide-react";

const socialLinks = [
  { icon: "telegram", label: "تيليجرام" },
  { icon: "mail", label: "البريد" },
  { icon: "mobile", label: "جوال" },
  { icon: "phone", label: "هاتف" },
];

const importantLinks = [
  "المدونة",
  "سياسة الاستخدام والخصوصية",
  "سياسة الاستبدال والاسترجاع",
  "خدماتنا",
];

function SocialIcon({ type }: { type: string }) {
  switch (type) {
    case "telegram":
      return (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21.2 2L2.5 10.2c-.7.3-.7 1.2 0 1.5l4.8 1.8 1.8 5.6c.2.5 1 .7 1.4.3l2.5-2.5 4.9 3.6c.6.4 1.4.1 1.5-.6L22.5 3c.1-.7-.6-1.3-1.3-1z" />
          <path d="M9 14l4-4" />
        </svg>
      );
    case "mail":
      return <Mail className="w-5 h-5" strokeWidth={1.5} />;
    case "mobile":
      return <Smartphone className="w-5 h-5" strokeWidth={1.5} />;
    case "phone":
      return <Phone className="w-5 h-5" strokeWidth={1.5} />;
    default:
      return null;
  }
}

export default function Footer() {
  const [email, setEmail] = useState("");

  return (
    <footer className="bg-gray-50 pt-8 pb-24 px-4">
      {/* Important Links */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="mb-8"
      >
        <h4 className="font-semibold text-base text-black mb-4 text-center">
          روابط مهمة
        </h4>
        <div className="space-y-3">
          {importantLinks.map((link) => (
            <a
              key={link}
              href="#"
              className="flex items-center justify-between text-gray-600 text-sm hover:text-gold transition-colors"
            >
              <span>{link}</span>
              <span className="text-gray-400 text-xs">{"<<"}</span>
            </a>
          ))}
        </div>
      </motion.div>

      {/* Newsletter */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="mb-8 text-center"
      >
        <h4 className="font-semibold text-base text-black mb-2">
          احصل على خصومات
        </h4>
        <p className="text-gray-600 text-[13px] mb-4 leading-relaxed">
          اشترك للحصول على عروض خاصة، وهدايا مجانية، وصفقات لا تتكرر
        </p>
        <div className="flex items-center border-b border-gray-200 mb-3">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="ادخل البريد الإلكتروني"
            className="flex-1 bg-transparent py-3 text-sm text-black placeholder:text-gray-400 outline-none text-right"
            dir="rtl"
          />
        </div>
        <button className="w-full bg-black text-white font-semibold text-sm py-3 rounded-lg hover:bg-gray-800 transition-colors">
          اشتراك
        </button>
      </motion.div>

      {/* App Download */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="flex items-center justify-center gap-4 mb-8"
      >
        {/* Google Play Badge */}
        <div className="bg-black rounded-lg px-3 py-2 flex items-center gap-2 h-11">
          <svg width="20" height="22" viewBox="0 0 24 26" fill="none">
            <path d="M1 3v20l11-10L1 3z" fill="#4285F4"/>
            <path d="M1 3l11 10 4.5-4.5L4.5 1C2.5 0 1 1 1 3z" fill="#EA4335"/>
            <path d="M1 23l11-10 4.5 4.5-8 4.5c-2 1-3.5 0-4.5-1.5L1 23z" fill="#34A853"/>
            <path d="M16.5 8.5L12 13l4.5 4.5 3-1.5c1.5-.5 2-2 2-3.5s-.5-3-2-3.5l-3-1.5z" fill="#FBBC04"/>
          </svg>
          <div className="flex flex-col">
            <span className="text-[9px] text-gray-400 leading-none">GET IT ON</span>
            <span className="text-xs text-white font-semibold leading-tight">Google Play</span>
          </div>
        </div>

        {/* App Store Badge */}
        <div className="bg-black rounded-lg px-3 py-2 flex items-center gap-2 h-11">
          <svg width="18" height="22" viewBox="0 0 20 24" fill="none">
            <path d="M16.3 12.8c.1-2.2 1.8-3.2 1.9-3.3-1-1.5-2.6-1.7-3.2-1.7-1.4-.1-2.7.8-3.4.8-.7 0-1.8-.8-2.9-.8C6.3 7.8 4 9.3 4 12.4c0 .9.2 1.9.5 2.9.4 1.3 1.9 4.4 3.4 4.3 1-.1 1.4-.7 2.5-.7 1.1 0 1.4.7 2.9.7 1.5 0 2.5-2 3.1-3.3-2-.9-2.1-3-.2-4.5zM13.2 6.3c.7-.9 1.2-2.1 1.1-3.3-1.1.1-2.3.7-3.1 1.6-.7.8-1.2 2-1 3.2 1.2.1 2.3-.5 3-1.5z" fill="white"/>
          </svg>
          <div className="flex flex-col">
            <span className="text-[9px] text-gray-400 leading-none">Download on the</span>
            <span className="text-xs text-white font-semibold leading-tight">App Store</span>
          </div>
        </div>
      </motion.div>

      {/* Social Links */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="flex items-center justify-center gap-6 mb-8"
      >
        {socialLinks.map((social) => (
          <a
            key={social.label}
            href="#"
            className="flex flex-col items-center gap-1.5 text-gray-400 hover:text-gold transition-colors"
          >
            <div className="w-10 h-10 rounded-full border border-gray-200 flex items-center justify-center">
              <SocialIcon type={social.icon} />
            </div>
            <span className="text-[11px]">{social.label}</span>
          </a>
        ))}
      </motion.div>

      {/* Certifications */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="flex flex-col items-center gap-3 mb-6"
      >
        <div className="flex items-center gap-2 text-gray-600 text-xs">
          <ShieldCheck className="w-4 h-4 text-success" />
          <span>موثق لدى المركز السعودي للأعمال</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white rounded-lg border border-gray-200 flex items-center justify-center">
            <Award className="w-5 h-5 text-gold" />
          </div>
          <div className="w-10 h-10 bg-white rounded-lg border border-gray-200 flex items-center justify-center">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#C5A55A" strokeWidth="1.5">
              <rect x="2" y="5" width="20" height="14" rx="2"/>
              <path d="M2 10h20" />
            </svg>
          </div>
        </div>
      </motion.div>

      {/* Copyright */}
      <div className="text-center">
        <p className="text-gray-400 text-xs">©2025 ابداع لاين | Ibdaa Line</p>
      </div>
    </footer>
  );
}
