import { User, ShoppingBag, Heart, Globe } from "lucide-react";

export default function Header() {
  return (
    <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-gray-200">
      <div className="flex items-center justify-between px-4 h-14">
        {/* Right side - Account & Cart */}
        <div className="flex items-center gap-3">
          <button className="p-1.5 hover:bg-gray-100 rounded-full transition-colors">
            <User className="w-6 h-6 text-black" strokeWidth={1.5} />
          </button>
          <button className="p-1.5 hover:bg-gray-100 rounded-full transition-colors relative">
            <ShoppingBag className="w-6 h-6 text-black" strokeWidth={1.5} />
            <span className="absolute -top-0.5 -right-0.5 bg-gold text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
              0
            </span>
          </button>
        </div>

        {/* Center - Logo */}
        <div className="flex flex-col items-center">
          <span className="font-tajawal font-bold text-lg text-gold leading-none tracking-wide">
            عبدالين
          </span>
        </div>

        {/* Left side - Wishlist & Language */}
        <div className="flex items-center gap-3">
          <button className="p-1.5 hover:bg-gray-100 rounded-full transition-colors">
            <Heart className="w-6 h-6 text-black" strokeWidth={1.5} />
          </button>
          <button className="p-1.5 hover:bg-gray-100 rounded-full transition-colors">
            <Globe className="w-6 h-6 text-black" strokeWidth={1.5} />
          </button>
        </div>
      </div>
    </header>
  );
}
