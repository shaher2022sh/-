export default function PromoMarquee() {
  const text = "عبدالين للثيمات الاحترافية.  ·  اختار ثيمك واطلبه الآن — تصاميم مبتكرة لمتجرك";

  return (
    <div className="bg-gold-light h-9 flex items-center overflow-hidden">
      <div className="flex animate-marquee whitespace-nowrap">
        {[...Array(6)].map((_, i) => (
          <span key={i} className="flex items-center gap-6 px-6">
            <span className="text-gold-dark text-[13px] font-medium font-cairo flex items-center gap-2">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="#A0843A">
                <path d="M12 2L8 8H4L6 12L2 16H8L12 22L16 16H22L18 12L20 8H16L12 2Z"/>
              </svg>
              {text}
            </span>
          </span>
        ))}
      </div>
    </div>
  );
}
