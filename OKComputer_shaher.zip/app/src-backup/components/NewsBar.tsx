export default function NewsBar() {
  const items = [
    { text: "معاينة ثيم (6.6)", type: "text" as const },
    { text: "معاينة في متجري", type: "badge" as const },
    { text: "شراء الثيم", type: "badge" as const },
  ];

  return (
    <div className="bg-gray-100 h-9 flex items-center overflow-hidden">
      <div className="flex animate-news-scroll whitespace-nowrap">
        {[...items, ...items, ...items, ...items].map((item, i) => (
          <span key={i} className="flex items-center gap-4 px-4">
            {item.type === "badge" ? (
              <span className="bg-[#DCF5E6] text-green-700 text-xs font-medium px-2.5 py-1 rounded-md">
                {item.text}
              </span>
            ) : (
              <span className="text-gray-400 text-xs">{item.text}</span>
            )}
            <span className="text-gray-300">·</span>
          </span>
        ))}
      </div>
    </div>
  );
}
