import { Eye, ExternalLink } from "lucide-react";
import { motion } from "framer-motion";

interface ProductCardProps {
  image: string;
  nameAr: string;
  nameEn: string;
  description: string;
  price: number;
  originalPrice?: number;
  discount?: string;
  tags: string[];
  category: string;
  sallaUrl: string;
  showLuxuryBadge?: boolean;
}

export default function ProductCard({
  image,
  nameAr,
  nameEn,
  description,
  price,
  originalPrice,
  discount,
  tags,
  category,
  sallaUrl,
  showLuxuryBadge = true,
}: ProductCardProps) {
  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2, ease: "easeOut" }}
      className="bg-white border border-gray-200 rounded-xl p-3 shadow-card hover:shadow-card-hover transition-shadow"
    >
      {/* Image container */}
      <div className="relative aspect-[4/3] rounded-lg overflow-hidden bg-gray-900 mb-3">
        <img
          src={image}
          alt={nameAr}
          className="w-full h-full object-cover"
          loading="lazy"
        />
        
        {/* Luxury badge */}
        {showLuxuryBadge && (
          <span className="absolute top-2 right-2 bg-gold text-white text-[11px] font-medium px-2 py-1 rounded">
            ثيم احترافي
          </span>
        )}
        
        {/* Discount badge */}
        {discount && (
          <span className="absolute top-2 left-2 bg-white border border-gold text-gold text-[11px] font-semibold px-2 py-1 rounded">
            {discount}
          </span>
        )}
        
        {/* Preview button */}
        <div className="absolute right-2 top-1/2 -translate-y-1/2 flex flex-col gap-2">
          <button className="w-8 h-8 bg-white/90 backdrop-blur rounded-full flex items-center justify-center shadow-sm hover:bg-gold hover:text-white transition-colors">
            <Eye className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Tags */}
      <div className="flex items-center gap-2 mb-2">
        <span className="text-gold text-xs font-medium">{category}</span>
        <span className="text-gray-300">|</span>
        {tags.map((tag) => (
          <span key={tag} className="text-gray-400 text-xs">{tag}</span>
        ))}
      </div>

      {/* Name */}
      <h3 className="text-base font-semibold text-black mb-1 leading-snug">
        {nameAr} — {nameEn}
      </h3>

      {/* Description */}
      <p className="text-gray-600 text-sm mb-3 line-clamp-2">{description}</p>

      {/* Price */}
      <div className="flex items-center gap-2 mb-3">
        <p className="text-lg font-bold text-black">{price} ر.س</p>
        {originalPrice && (
          <p className="text-sm text-gray-400 line-through">{originalPrice} ر.س</p>
        )}
      </div>

      {/* CTA - Link to Salla */}
      <a
        href={sallaUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="w-full bg-gold text-white font-semibold text-sm py-3 rounded-lg hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
      >
        <span>شراء من سلة</span>
        <ExternalLink className="w-4 h-4" />
      </a>
    </motion.div>
  );
}
