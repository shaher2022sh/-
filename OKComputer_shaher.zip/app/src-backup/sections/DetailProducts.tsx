import { motion } from "framer-motion";
import ProductCard from "@/components/ProductCard";

const products = [
  {
    image: "/images/product-ring-2.jpg",
    nameAr: "ثيم الأزياء",
    nameEn: "Fashion Theme",
    description: "تصميم عصري للأزياء والملابس — مرن ومتجاوب",
    price: 279,
    originalPrice: 999,
    discount: "خصم 72%",
    tags: ["#أزياء", "#ملابس", "#عصري"],
    category: "تصنيفات",
    sallaUrl: "https://salla.sa/abdalin",
  },
  {
    image: "/images/product-earring-1.jpg",
    nameAr: "ثيم الإلكترونيات",
    nameEn: "Electronics Theme",
    description: "تصميم تقني للإلكترونيات — احترافي وعملي",
    price: 249,
    originalPrice: 899,
    discount: "خصم 72%",
    tags: ["#إلكترونيات", "#تقني", "#احترافي"],
    category: "تصنيفات",
    sallaUrl: "https://salla.sa/abdalin",
  },
];

export default function DetailProducts() {
  return (
    <section className="px-4 py-6 bg-white">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="font-tajawal font-bold text-[22px] text-black leading-snug mb-5"
      >
        لمن يهتم بأدق التفاصيل... ثيماتنا صُممت خصيصاً لك
      </motion.h2>

      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="grid grid-cols-2 gap-3"
      >
        {products.map((product, i) => (
          <motion.div
            key={product.nameEn}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            viewport={{ once: true }}
          >
            <ProductCard {...product} />
          </motion.div>
        ))}
      </motion.div>
    </section>
  );
}
