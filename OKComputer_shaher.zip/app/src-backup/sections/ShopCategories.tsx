import { useState } from "react";
import { motion } from "framer-motion";
import { Copy, Check } from "lucide-react";

export default function ShopCategories() {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText("ABALIN20");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section className="px-4 py-6 bg-white">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-4"
      >
        <h3 className="font-tajawal font-bold text-lg text-black mb-1">
          تصفح حسب التصنيف
        </h3>
        <p className="text-gray-600 text-sm">
          اختار التصنيف اللي يناسب متجرك
        </p>
      </motion.div>

      {/* Coupon code */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="bg-gold-light border border-dashed border-gold rounded-lg px-4 py-3 flex items-center justify-center gap-3 mb-6"
      >
        <span className="text-sm text-black">كود خصم</span>
        <span className="font-bold text-gold text-base">ABALIN20</span>
        <button
          onClick={handleCopy}
          className="p-1.5 hover:bg-gold/20 rounded-full transition-colors"
        >
          {copied ? (
            <Check className="w-4 h-4 text-success" />
          ) : (
            <Copy className="w-4 h-4 text-gold" />
          )}
        </button>
      </motion.div>

      {/* Category images */}
      <div className="flex gap-3 overflow-x-auto scrollbar-hide snap-x snap-mandatory pb-2">
        {[
          { img: "/images/promo-banner-1.jpg", label: "إلكترونية" },
          { img: "/images/promo-banner-2.jpg", label: "فاخرة" },
          { img: "/images/hero-banner.jpg", label: "عصرية" },
          { img: "/images/luxury-touch.jpg", label: "متخصصة" },
        ].map((cat, i) => (
          <motion.div
            key={cat.label}
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            viewport={{ once: true }}
            className="flex-shrink-0 w-[140px] snap-start"
          >
            <div className="rounded-xl overflow-hidden h-[100px] mb-2">
              <img
                src={cat.img}
                alt={cat.label}
                className="w-full h-full object-cover"
                loading="lazy"
              />
            </div>
            <p className="text-center text-sm font-medium text-black">{cat.label}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
