import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, X } from "lucide-react";

const faqs = [
  { q: "ما طرق الدفع المتاحة في المتجر؟", num: "01" },
  { q: "هل يمكن تصميم قطعة خاصة حسب الطلب؟", num: "02" },
  { q: "كم يستغرق توصيل الطلب؟", num: "03" },
  { q: "هل يمكن استرجاع أو استبدال المنتج؟", num: "04" },
  { q: "هل يمكن تعديل المقاس بعد الشراء؟", num: "05" },
  { q: "هل تقدمون خدمة تغليف الهدايا؟", num: "06" },
  { q: "هل المجوهرات أصلية ومضمونة؟", num: "07" },
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section className="bg-gold-light py-8 px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-6"
      >
        <h2 className="font-tajawal font-bold text-[22px] text-black mb-1">
          الأسئلة الشائعة
        </h2>
        <p className="text-gray-600 text-sm">
          نحن سعداء بالرد على استفساراتكم
        </p>
      </motion.div>

      <div className="space-y-2.5">
        {faqs.map((faq, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            viewport={{ once: true }}
            className="bg-white rounded-xl overflow-hidden"
          >
            <button
              onClick={() => setOpenIndex(openIndex === i ? null : i)}
              className="w-full flex items-center gap-3 px-4 py-4 text-right"
            >
              <span className="text-gold font-semibold text-base min-w-[28px]">
                {faq.num}
              </span>
              <span className="flex-1 text-sm font-medium text-black">
                {faq.q}
              </span>
              {openIndex === i ? (
                <X className="w-5 h-5 text-gray-400 flex-shrink-0" />
              ) : (
                <Plus className="w-5 h-5 text-gray-400 flex-shrink-0" />
              )}
            </button>

            <AnimatePresence>
              {openIndex === i && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                  className="overflow-hidden"
                >
                  <div className="px-4 pb-4 pr-12 text-gray-600 text-sm leading-relaxed">
                    نحن نسعى دائماً لتقديم أفضل خدمة ممكنة. يمكنك التواصل مع فريق
                    خدمة العملاء للحصول على مزيد من المعلومات حول هذا الموضوع.
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
