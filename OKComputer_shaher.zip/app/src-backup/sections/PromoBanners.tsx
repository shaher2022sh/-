import { motion } from "framer-motion";

const banners = [
  {
    image: "/images/promo-banner-1.jpg",
    title: "اختياري قرطك من مجموعتنا، وخلّي ستايلك ينطق فخامة",
    overlay: "from-black/60 via-black/30 to-transparent",
  },
  {
    image: "/images/promo-banner-2.jpg",
    title: "كل خاتم يلمع بفخامة تنشاف من بعيد، ويترك انطباع ما ينسى",
    overlay: "from-black/60 via-black/30 to-transparent",
  },
];

const categoryBtns = ["خواتم", "أقراط", "سلاسل", "أساور"];

export default function PromoBanners() {
  return (
    <section className="py-4 px-4">
      <div className="flex gap-3 overflow-x-auto scrollbar-hide snap-x snap-mandatory pb-2">
        {banners.map((banner, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.15 }}
            viewport={{ once: true }}
            className="relative flex-shrink-0 w-[85%] h-[160px] rounded-xl overflow-hidden snap-start"
          >
            <img
              src={banner.image}
              alt={banner.title}
              className="w-full h-full object-cover"
              loading="lazy"
            />
            <div className={`absolute inset-0 bg-gradient-to-t ${banner.overlay}`} />
            <div className="absolute inset-0 p-4 flex flex-col justify-between">
              <p className="text-white text-sm font-medium leading-relaxed max-w-[200px]">
                {banner.title}
              </p>
              <div className="flex gap-2">
                {categoryBtns.slice(0, 3).map((btn) => (
                  <span
                    key={btn}
                    className="text-white/90 text-xs border border-white/40 rounded-full px-3 py-1 backdrop-blur-sm"
                  >
                    {btn}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
