import { motion } from "framer-motion";

export default function LuxuryBanner() {
  return (
    <section className="relative">
      {/* Main banner */}
      <div className="relative w-full h-[200px] overflow-hidden">
        <img
          src="/images/luxury-touch.jpg"
          alt="ثيمات فاخرة"
          className="w-full h-full object-cover"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-black/50" />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="absolute inset-0 flex flex-col items-center justify-center px-6 text-center"
        >
          <h2 className="font-tajawal font-bold text-2xl text-white mb-2">
            ثيم يليق بمتجرك
          </h2>
          <p className="text-white/80 text-sm mb-5 max-w-[300px] leading-relaxed">
            تصاميم مبتكرة بجودة عالية — ثبته بضغطة واحدة
          </p>
          <a
            href="https://salla.sa/abdalin"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-white text-black font-semibold text-sm px-8 py-2.5 rounded-lg hover:bg-gold-light transition-colors"
          >
            اكتشف الثيمات
          </a>
        </motion.div>
      </div>

      {/* Category images row */}
      <div className="flex gap-3 px-4 -mt-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          viewport={{ once: true }}
          className="flex-1 rounded-xl overflow-hidden h-[120px] relative"
        >
          <img
            src="/images/category-rings.jpg"
            alt="ثيمات إلكترونية"
            className="w-full h-full object-cover"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-black/30" />
          <span className="absolute bottom-3 right-3 text-white font-semibold text-sm">
            إلكترونية
          </span>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          viewport={{ once: true }}
          className="flex-1 rounded-xl overflow-hidden h-[120px] relative"
        >
          <img
            src="/images/category-earrings.jpg"
            alt="ثيمات فاخرة"
            className="w-full h-full object-cover"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-black/30" />
          <span className="absolute bottom-3 right-3 text-white font-semibold text-sm">
            فاخرة
          </span>
        </motion.div>
      </div>
    </section>
  );
}
