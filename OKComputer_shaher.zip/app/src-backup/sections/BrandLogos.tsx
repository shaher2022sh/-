const brands = ["L'AZURDE", "ARCADIA", "NOMAR", "SEQUENCER"];

export default function BrandLogos() {
  const allBrands = [...brands, ...brands, ...brands, ...brands];

  return (
    <section className="bg-white py-5 overflow-hidden border-t border-gray-100">
      <div className="flex animate-marquee-reverse whitespace-nowrap">
        {allBrands.map((brand, i) => (
          <span
            key={i}
            className="flex-shrink-0 px-8 text-gray-400 text-sm font-semibold tracking-wider uppercase"
          >
            {brand}
          </span>
        ))}
      </div>
    </section>
  );
}
