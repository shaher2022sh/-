import { useState } from "react";

const pills = ["خواتم", "سلاسل", "أقراط", "أساور"];

export default function CategoryPills() {
  const [active, setActive] = useState("خواتم");

  return (
    <section className="px-4 py-3 bg-white">
      <div className="flex gap-2 overflow-x-auto scrollbar-hide">
        {pills.map((pill) => (
          <button
            key={pill}
            onClick={() => setActive(pill)}
            className={`flex-shrink-0 px-5 py-2 rounded-full text-[13px] font-medium transition-all ${
              active === pill
                ? "bg-gold text-white"
                : "bg-gold-light text-gold-dark hover:bg-gold/20"
            }`}
          >
            {pill}
          </button>
        ))}
      </div>
    </section>
  );
}
