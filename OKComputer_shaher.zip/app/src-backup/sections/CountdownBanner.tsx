import { motion } from "framer-motion";
import CountdownTimer from "@/components/CountdownTimer";

export default function CountdownBanner() {
  return (
    <section className="relative w-full h-[120px] overflow-hidden">
      <img
        src="/images/countdown-bg.jpg"
        alt="عروض تنتهي قريباً"
        className="w-full h-full object-cover"
        loading="lazy"
      />
      <div className="absolute inset-0 bg-black/50" />
      
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="absolute inset-0 flex items-center justify-between px-4"
      >
        <div>
          <h3 className="font-tajawal font-bold text-lg text-white mb-2">
            عروض تنتهي قريباً
          </h3>
          <CountdownTimer />
        </div>
        
        <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-gold/50 flex-shrink-0">
          <img
            src="/images/product-necklace-1.jpg"
            alt="عرض"
            className="w-full h-full object-cover"
          />
        </div>
      </motion.div>
    </section>
  );
}
