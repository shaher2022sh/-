import { motion } from "framer-motion";

export default function HeroBanner() {
  return (
    <section className="relative w-full h-[280px] overflow-hidden">
      {/* Background image with Ken Burns */}
      <div className="absolute inset-0 animate-ken-burns">
        <img
          src="/images/hero-banner.jpg"
          alt="ثيمات عبدالين"
          className="w-full h-full object-cover"
        />
      </div>
      
      {/* Overlay gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-black/80" />

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center h-full px-6 text-center">
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
          className="font-tajawal font-bold text-2xl text-white mb-3 leading-tight"
        >
          ثيمات احترافية لمتجرك
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35, duration: 0.6 }}
          className="text-white/80 text-sm mb-6 leading-relaxed max-w-[300px]"
        >
          تصاميم مبتكرة تصلح لجميع المتاجر — اختار ثيمك وثبته بكل سهولة
        </motion.p>
        <motion.a
          href="https://salla.sa/abdalin"
          target="_blank"
          rel="noopener noreferrer"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5, duration: 0.4 }}
          className="bg-gold text-white font-semibold text-sm px-8 py-3 rounded-lg hover:brightness-110 transition-all"
        >
          تصفح المتجر
        </motion.a>
      </div>
    </section>
  );
}
