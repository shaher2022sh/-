import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";
import ProductCard from "@/components/ProductCard";
import StarRating from "@/components/StarRating";

const products = [
  {
    image: "/images/product-bracelet-1.jpg",
    nameAr: "ثيم المجوهرات",
    nameEn: "Jewelry Theme",
    description: "تصميم فاخر للمجوهرات والذهب — ألوان ذهبية وأنيقة",
    price: 349,
    originalPrice: 1199,
    discount: "خصم 71%",
    tags: ["#مجوهرات", "#ذهب", "#فاخر"],
    category: "متخصص",
    sallaUrl: "https://salla.sa/abdalin",
  },
  {
    image: "/images/product-bracelet-2.jpg",
    nameAr: "ثيم العطور",
    nameEn: "Perfume Theme",
    description: "تصميم أنيق للعطور والتجميل — فخامة وبساطة",
    price: 299,
    originalPrice: 899,
    discount: "خصم 67%",
    tags: ["#عطور", "#تجميل", "#أنيق"],
    category: "متخصص",
    sallaUrl: "https://salla.sa/abdalin",
  },
];

export default function FeaturedReviews() {
  return (
    <section className="px-4 py-8 bg-gray-50">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-6"
      >
        <div className="flex items-center justify-center gap-2 mb-1">
          <h2 className="font-tajawal font-bold text-[22px] text-black">أحدث التصاميم</h2>
          <Sparkles className="w-5 h-5 text-gold" strokeWidth={1.5} />
        </div>
        <p className="text-gray-600 text-sm mb-2">تصاميم حديثة تلبي ذوقك</p>
        <StarRating />
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="grid grid-cols-2 gap-3"
      >
        {products.map((product, i) => (
          <motion.div
            key={product.nameEn}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            viewport={{ once: true }}
          >
            <ProductCard {...product} />
          </motion.div>
        ))}
      </motion.div>
    </section>
  );
}
