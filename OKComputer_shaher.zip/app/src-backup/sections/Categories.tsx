import { useState } from "react";
import { motion } from "framer-motion";
import { Palette, Smartphone, ShoppingBag, Sparkles } from "lucide-react";

const categories = [
  { id: "all", label: "الكل", icon: Sparkles },
  { id: "ecommerce", label: "متاجر", icon: ShoppingBag },
  { id: "modern", label: "عصري", icon: Smartphone },
  { id: "luxury", label: "فاخر", icon: Palette },
];

export default function Categories() {
  const [active, setActive] = useState("all");

  return (
    <section className="bg-white py-4 px-4">
      <div className="flex items-center justify-around">
        {categories.map((cat, i) => {
          const Icon = cat.icon;
          return (
            <motion.button
              key={cat.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              onClick={() => setActive(cat.id)}
              className="flex flex-col items-center gap-2"
            >
              <div
                className={`w-12 h-12 rounded-full border flex items-center justify-center transition-all duration-150 ${
                  active === cat.id
                    ? "border-gold bg-gold/5 text-gold"
                    : "border-gray-200 text-gray-400 hover:border-gold/50"
                }`}
              >
                <Icon className="w-5 h-5" strokeWidth={1.5} />
              </div>
              <span
                className={`text-xs font-medium ${
                  active === cat.id ? "text-gold" : "text-black"
                }`}
              >
                {cat.label}
              </span>
            </motion.button>
          );
        })}
      </div>
    </section>
  );
}
