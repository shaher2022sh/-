import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";
import ProductCard from "@/components/ProductCard";
import StarRating from "@/components/StarRating";

const products = [
  {
    image: "/images/promo-banner-1.jpg",
    nameAr: "ثيم رابح",
    nameEn: "Rabeh Theme",
    description: "ثيم إلكتروني احترافي مع معاينة حية — مناسب لجميع المتاجر",
    price: 260,
    originalPrice: 1399,
    discount: "خصم 81%",
    tags: ["#إلكترونيات", "#متجر", "#تجاوب"],
    category: "ثيمات",
    sallaUrl: "https://salla.sa/abdalin",
  },
  {
    image: "/images/promo-banner-2.jpg",
    nameAr: "ثيم فخامة",
    nameEn: "Luxury Theme",
    description: "تصميم فاخر بألوان ذهبية — مثالي للمجوهرات والأزياء",
    price: 349,
    originalPrice: 999,
    discount: "خصم 65%",
    tags: ["#فاخر", "#مجوهرات", "#أزياء"],
    category: "ثيمات",
    sallaUrl: "https://salla.sa/abdalin",
  },
  {
    image: "/images/hero-banner.jpg",
    nameAr: "ثيم الاحترافية",
    nameEn: "Pro Theme",
    description: "تصميم عصري بتقنية أحدث — سرعة وأداء ممتاز",
    price: 199,
    originalPrice: 799,
    discount: "خصم 75%",
    tags: ["#احترافي", "#سريع", "#عصري"],
    category: "ثيمات",
    sallaUrl: "https://salla.sa/abdalin",
  },
];

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 },
};

export default function FeaturedProducts() {
  return (
    <section className="px-4 py-6 bg-white">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-6"
      >
        <div className="flex items-center justify-center gap-2 mb-1">
          <h2 className="font-tajawal font-bold text-2xl text-black">ثيماتنا المميزة</h2>
          <Sparkles className="w-6 h-6 text-gold" strokeWidth={1.5} />
        </div>
        <p className="text-gray-400 text-sm mb-2">تصاميم احترافية بأسعار مميزة</p>
        <StarRating />
      </motion.div>

      {/* Products */}
      <motion.div
        variants={container}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true }}
        className="space-y-4"
      >
        {products.map((product) => (
          <motion.div key={product.nameEn} variants={item}>
            <ProductCard {...product} />
          </motion.div>
        ))}
      </motion.div>
    </section>
  );
}
