import Header from "@/components/Header";
import NewsBar from "@/components/NewsBar";
import PromoMarquee from "@/components/PromoMarquee";
import BottomNav from "@/components/BottomNav";
import WhatsAppButton from "@/components/WhatsAppButton";
import BackToTop from "@/components/BackToTop";

import HeroBanner from "@/sections/HeroBanner";
import Categories from "@/sections/Categories";
import PromoBanners from "@/sections/PromoBanners";
import CategoryPills from "@/sections/CategoryPills";
import FeaturedProducts from "@/sections/FeaturedProducts";
import CountdownBanner from "@/sections/CountdownBanner";
import FeaturedReviews from "@/sections/FeaturedReviews";
import DetailProducts from "@/sections/DetailProducts";
import FAQ from "@/sections/FAQ";
import BrandLogos from "@/sections/BrandLogos";
import LuxuryBanner from "@/sections/LuxuryBanner";
import ShopCategories from "@/sections/ShopCategories";
import Footer from "@/sections/Footer";

function App() {
  return (
    <div className="min-h-screen bg-gray-100" dir="rtl">
      {/* Mobile container */}
      <div className="max-w-[430px] mx-auto bg-white min-h-screen relative shadow-xl">
        {/* Top bars */}
        <NewsBar />
        <PromoMarquee />
        <Header />

        {/* Main content */}
        <main className="pb-4">
          <HeroBanner />
          <Categories />
          <PromoBanners />
          <CategoryPills />
          <FeaturedProducts />
          <CountdownBanner />
          <FeaturedReviews />
          <DetailProducts />
          <LuxuryBanner />
          <ShopCategories />
          <FAQ />
          <BrandLogos />
          <Footer />
        </main>

        {/* Floating elements */}
        <WhatsAppButton />
        <BackToTop />
        <BottomNav />
      </div>
    </div>
  );
}

export default App;
