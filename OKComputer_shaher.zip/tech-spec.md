# Fakhr Jewelry — Tech Spec

## المكوّنات

### shadcn/ui
- **Accordion** — الأسئلة الشائعة (FAQ)
- **Input** — حقل البريد الإلكتروني
- **Badge** — عدّاد السلة، علامات الخصم

### مكوّنات مخصصة

| المكوّن | الوصف | الموقع |
|---------|-------|--------|
| `GoldButton` | زر ذهبي أساسي مع hover effect | `components/GoldButton.tsx` |
| `GoldOutlineButton` | زر حدود ذهبية | `components/GoldOutlineButton.tsx` |
| `CircleIcon` | أيقونة دائرية للفئات | `components/CircleIcon.tsx` |
| `ProductCard` | بطاقة منتج كاملة (صورة + تفاصيل + سلة) | `components/ProductCard.tsx` |
| `DiscountBadge` | علامة خصم مطلقة | `components/DiscountBadge.tsx` |
| `LuxuryBadge` | علامة "عبر الفخامة" | `components/LuxuryBadge.tsx` |
| `CategoryPill` | زر فئة pill-shaped | `components/CategoryPill.tsx` |
| `CountdownTimer` | عداد تنازلي (يوم/ساعة/دقيقة/ثانية) | `components/CountdownTimer.tsx` |
| `StarRating` | 5 نجوم ذهبية | `components/StarRating.tsx` |
| `NewsTicker` | شريط أخبار متنقل | `components/NewsTicker.tsx` |
| `Marquee` | شريط نصي متنقل بشكل loop | `components/Marquee.tsx` |
| `BottomNav` | شريط تنقل سفلي ثابت | `components/BottomNav.tsx` |
| `WhatsAppButton` | زر واتساب عائم | `components/WhatsAppButton.tsx` |
| `BackToTop` | زر العودة للأعلى | `components/BackToTop.tsx` |
| `Header` | الهيدر مع الشعار | `components/Header.tsx` |
| `Footer` | الفوتر الشامل | `components/Footer.tsx` |

## الأنيميشن

| الأنيميشن | المكتبة | التنفيذ | التعقيد |
|-----------|---------|---------|---------|
| دخول أقسام scroll | Framer Motion | `whileInView` + stagger children | منخفض |
| Hero Ken Burns | CSS | `@keyframes scale` 8s infinite | منخفض |
| Hero text reveal | Framer Motion | stagger fade + translateY | منخفض |
| hover بطاقات منتج | CSS | `transition: transform 200ms` | منخفض |
| hover أيقونات دائرية | CSS | `transition: scale + border-color` | منخفض |
| Marquee loop | CSS | `@keyframes translateX` infinite | منخفض |
| News ticker | CSS | `@keyframes translateX` infinite | منخفض |
| WhatsApp pulse | CSS | `@keyframes shadow ripple` 2s infinite | منخفض |
| BackToTop fade | Framer Motion | `AnimatePresence` + opacity | منخفض |
| FAQ expand | Framer Motion | `AnimatePresence` + height auto | منخفض |
| Brand logos scroll | CSS | `@keyframes translateX` infinite | منخفض |

**قرار:** لا حاجة لـ GSAP — كل الأنيميشن بسيطة ويمكن تنفيذها بـ Framer Motion + CSS.

## التبعيات

```json
{
  "framer-motion": "^11.0.0",
  "lucide-react": "^0.400.0"
}
```

## البنية

```
src/
├── sections/
│   ├── NewsBar.tsx           # شريط الأخبار العلوي
│   ├── PromoMarquee.tsx      # شريط مارquee الترويجي
│   ├── Categories.tsx        # أيقونات الفئات
│   ├── PromoBanners.tsx      # البانرات الترويجية
│   ├── CategoryPills.tsx     # أزرار الفئات
│   ├── FeaturedProducts.tsx  # منتجات مميزة
│   ├── CountdownBanner.tsx   # بانر العد التنازلي
│   ├── FeaturedReviews.tsx   # روائع مميزة
│   ├── DetailProducts.tsx    # "لمن تهتم بأدق التفاصيل"
│   ├── FAQ.tsx               # الأسئلة الشائعة
│   ├── BrandLogos.tsx        # شعارات الشركاء
│   ├── LuxuryBanner.tsx      # بانر "لمسة فخامة"
│   ├── ShopCategories.tsx    # تسوق + كود خصم
│   └── Footer.tsx            # الفوتر
├── components/
│   ├── Header.tsx
│   ├── BottomNav.tsx
│   ├── WhatsAppButton.tsx
│   ├── BackToTop.tsx
│   ├── GoldButton.tsx
│   ├── GoldOutlineButton.tsx
│   ├── CircleIcon.tsx
│   ├── ProductCard.tsx
│   ├── DiscountBadge.tsx
│   ├── LuxuryBadge.tsx
│   ├── CategoryPill.tsx
│   ├── CountdownTimer.tsx
│   ├── StarRating.tsx
│   ├── NewsTicker.tsx
│   └── Marquee.tsx
├── App.tsx
└── main.tsx
```

## ملاحظات

- **RTL**: `dir="rtl"` على `<html>`، كل المسارات تعمل بشكل عكسي
- **Mobile-first**: max-width 430px، centered على الشاشات الأكبر
- **Fonts**: Cairo + Tajawal من Google Fonts (يتم تحميلهم في index.html)
- **Images**: تُحفظ في `public/images/`
