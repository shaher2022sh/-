# رفع الثيم على GitHub — خطوات سريعة

## 1. أنشئ المستودع
- ادخل https://github.com/new
- اسم المستودع: `ibdaa-line-theme`
- اختر **Public**
- اضغط **Create repository**

## 2. ارفع الملفات (من الموقع)
- في صفحة المستودع اضغط **"uploading an existing file"**
- أو اسحب ملفات الثيم مباشرة

## 3. ارفع من Terminal
```bash
# افتح Terminal/CMD في مجلد theme
cd theme

# init
git init

# commit
git add .
git commit -m "Ibdaa Line Theme v1.0"

# ربط بالمستودع (غيّر USERNAME)
git remote add origin https://github.com/USERNAME/ibdaa-line-theme.git

# ارفع
git branch -M main
git push -u origin main
```

## 4. ربط بسلة
- ارجع لـ https://portal.salla.partners
- الثيمات → استيراد من GitHub
- اكتب: `USERNAME/ibdaa-line-theme`
