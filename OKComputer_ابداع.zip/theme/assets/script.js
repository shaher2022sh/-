/**
 * ابداع لاين — Ibdaa Line Theme
 * Salla Theme JavaScript
 */

// Mobile Menu Toggle
function toggleMenu() {
  document.getElementById('mobileMenu').classList.toggle('open');
}

// Close mobile menu when clicking outside
document.addEventListener('click', function(e) {
  const menu = document.getElementById('mobileMenu');
  const toggle = document.querySelector('.menu-toggle');
  if (menu.classList.contains('open') && 
      !menu.contains(e.target) && 
      !toggle.contains(e.target)) {
    menu.classList.remove('open');
  }
});

// Product Image Switcher
function changeImage(src) {
  const mainImage = document.getElementById('mainImage');
  if (mainImage) {
    mainImage.src = src;
  }
  // Update active thumbnail
  document.querySelectorAll('.thumb-btn').forEach(btn => {
    btn.classList.remove('active');
    if (btn.querySelector('img')?.src === src) {
      btn.classList.add('active');
    }
  });
}

// Quantity Adjuster
function adjustQty(delta) {
  const input = document.getElementById('qtyInput');
  const formQty = document.getElementById('formQty');
  if (!input) return;
  
  let newVal = parseInt(input.value) + delta;
  if (newVal < 1) newVal = 1;
  if (newVal > 99) newVal = 99;
  
  input.value = newVal;
  if (formQty) formQty.value = newVal;
}

// Cart Quantity Update
function updateCartQty(itemId, delta) {
  // This would typically make an AJAX request
  // For now, reload the page
  window.location.reload();
}

// Product Tabs
function switchTab(btn, tabId) {
  // Remove active from all buttons
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');

  // Hide all panels
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  
  // Show target panel
  const panel = document.getElementById('tab-' + tabId);
  if (panel) panel.classList.add('active');
}

// Wishlist Toggle
function toggleWishlist(btn) {
  btn.classList.toggle('active');
  if (btn.classList.contains('active')) {
    btn.innerHTML = '♥ المفضلة';
    showToast('تم الإضافة للمفضلة');
  } else {
    btn.innerHTML = '♡ المفضلة';
    showToast('تم الإزالة من المفضلة');
  }
}

// Toast Notification
function showToast(message) {
  // Remove existing toast
  const existing = document.querySelector('.toast-notification');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.className = 'toast-notification';
  toast.style.cssText = `
    position: fixed;
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    background: #1A1040;
    color: #fff;
    padding: 12px 24px;
    border-radius: 8px;
    font-size: 14px;
    z-index: 1000;
    animation: toastIn 0.3s ease, toastOut 0.3s ease 2.7s;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
  `;
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => toast.remove(), 3000);
}

// Add toast animations
const toastStyles = document.createElement('style');
toastStyles.textContent = `
  @keyframes toastIn {
    from { opacity: 0; transform: translateX(-50%) translateY(-10px); }
    to { opacity: 1; transform: translateX(-50%) translateY(0); }
  }
  @keyframes toastOut {
    from { opacity: 1; transform: translateX(-50%) translateY(0); }
    to { opacity: 0; transform: translateX(-50%) translateY(-10px); }
  }
`;
document.head.appendChild(toastStyles);

// Add to Cart with Feedback
document.querySelectorAll('.add-to-cart-form').forEach(form => {
  form.addEventListener('submit', function(e) {
    const btn = this.querySelector('.add-to-cart-btn');
    if (btn) {
      const originalText = btn.innerHTML;
      btn.innerHTML = '✓ تم الإضافة';
      btn.style.background = '#22C55E';
      
      setTimeout(() => {
        btn.innerHTML = originalText;
        btn.style.background = '';
      }, 1500);
    }
  });
});

// Sticky Header Shadow
let lastScroll = 0;
window.addEventListener('scroll', function() {
  const header = document.querySelector('.main-header');
  if (window.scrollY > 10) {
    header.style.boxShadow = '0 2px 12px rgba(26, 16, 64, 0.1)';
  } else {
    header.style.boxShadow = '';
  }
});

// Lazy load images
document.querySelectorAll('img[loading="lazy"]').forEach(img => {
  img.addEventListener('load', function() {
    this.style.opacity = '1';
  });
  img.style.opacity = '0';
  img.style.transition = 'opacity 0.3s ease';
});

// Initialize
document.addEventListener('DOMContentLoaded', function() {
  console.log('🎨 Ibdaa Line Theme loaded successfully');
});
